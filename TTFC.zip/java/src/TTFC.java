class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class ExceptionHandlingExample {

    public static void main(String[] args) {
        try {
            
            throwCustomException();
            methodWithThrows();

        } catch (CustomException e) {
            System.out.println("Caught CustomException: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Caught ArithmeticException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed");
        }
    }

    private static void throwCustomException() throws CustomException {
        System.out.println("\nExample 1: Using 'throw' to throw a custom exception");
        throw new CustomException("This is a custom exception");
    }

    private static void methodWithThrows() throws ArithmeticException {
        System.out.println("\nExample 2: Using 'throws' to declare an exception");
        int result = 10 / 0; // Attempting to divide by zero
        System.out.println("Result: " + result); // This line won't be executed
    }
}